from prettytable import PrettyTable

import mysql.connector

cnx = mysql.connector.connect(user='com303nle6', password='nl2520nl',
                              host='136.244.224.221',
                              database='com303nle6')


cursor = cnx.cursor()

class Query:
    # outputs top n selling products in each state
    def top_selling_products_by_state(self,n):
        cursor.execute(
            '''
                SELECT 
                    state,
                    item_name,
                    SUM(quantity) AS total_sold
                FROM 
                    stores, ships, orders, order_items, apparel
                WHERE 
                    stores.store_id = ships.store_id
                    AND ships.order_id = orders.order_id
                    AND orders.order_id = order_items.order_id
                    AND order_items.apparel_id = apparel.apparel_id
                GROUP BY 
                    state,
                    item_name
                ORDER BY 
                    state,
                    total_sold DESC
            '''
        )

        items = cursor.fetchall()

        # create table
        table = PrettyTable()
        table.field_names = ["State", "Apparel Name", "Quantity Sold"]

        hashmap = {}
        for item in items:
            state, item_name, total_sold = item
            if state not in hashmap:
                hashmap[state] = 1
            else:
                hashmap[state] += 1
            
            # get top k products in each state
            if hashmap[state] <= n:
                # add rows to the table
                table.add_row([state, item_name, total_sold])
        

        return table

    # output n stores with top number of products
    def top_stores_by_sales(self,n):
        cursor.execute(
            '''
            SELECT 
                s.store_id,
                CONCAT(s.address, ', ', s.city, ', ', s.state) AS store_location,
                SUM(oi.quantity) AS total_sales
            FROM 
                customer_orders co
                JOIN order_items oi ON co.order_id = oi.order_id
                JOIN ships sh ON co.order_id = sh.order_id
                JOIN stores s ON sh.store_id = s.store_id
            GROUP BY 
                s.store_id, 
                store_location
            ORDER BY 
                total_sales DESC
            LIMIT %s;
            ''', (n, )
        )

        items = cursor.fetchall()

        table = PrettyTable()
        table.field_names = ["Store ID", "Store Location", "Total Products Sold"]
        for item in items:
            store, location, sales = item
            table.add_row([store, location, sales])
        return table
    
    # output total revenues for all stores 
    def total_revenue_all_stores(self):
        cursor.execute(
            '''
            SELECT s.store_id,
            CONCAT(s.address, ', ', s.city, ', ', s.state) AS full_address,
            SUM(oi.quantity * a.price) AS total_revenue
            FROM stores s
            LEFT JOIN ships sh ON s.store_id = sh.store_id
            LEFT JOIN order_items oi ON sh.order_id = oi.order_id
            LEFT JOIN apparel a ON oi.apparel_id = a.apparel_id
            GROUP BY s.store_id, full_address
            ORDER BY total_revenue DESC;
            '''
        )

        items = cursor.fetchall()

        table = PrettyTable()
        table.field_names = ["Store ID", "Store Location", "Total Revenue"]
        for item in items:
            store, location, revenue = item
            if not revenue:
                revenue = 0
            table.add_row([store, location, revenue])
        return table
    
    # output the stores where item1 outsells item2
    def outsell(self,item1, item2):
        query = f'''
            SELECT
                has1.store_id,
                has1.quantity AS item1_quantity,
                has2.quantity AS item2_quantity
            FROM
                com303fpfm.has has1
            INNER JOIN
                com303fpfm.has has2 ON has1.store_id = has2.store_id
            INNER JOIN
                com303fpfm.order_items oi1 ON has1.apparel_id = oi1.apparel_id
            INNER JOIN
                com303fpfm.order_items oi2 ON has2.apparel_id = oi2.apparel_id
            INNER JOIN
                com303fpfm.customer_orders co1 ON oi1.order_id = co1.order_id
            INNER JOIN
                com303fpfm.customer_orders co2 ON oi2.order_id = co2.order_id
            WHERE
                has1.apparel_id = {item1}
                AND has2.apparel_id = {item2}
                AND oi1.quantity > oi2.quantity
            GROUP BY
                has1.store_id, has1.quantity, has2.quantity;

        '''
        cursor.execute(query)

        info = cursor.fetchall()

        table = PrettyTable()
        table.field_names = ["Store ID",  "Item " + str(item1) + " Quantity", "Item " + str(item2) + " Quantity"]
        for item in info:
            store, item1, item2 = item
            if item1 > item2:
                table.add_row([store, item1, item2])
        # return table
        return table
        
    # output top 3 types/categories of product sold
    def top_selling_categories(self):
        query = '''
            SELECT
                'running shoes' AS product_type,
                COUNT(*) AS total_orders
            FROM
                com303fpfm.order_items oi
            INNER JOIN
                running_shoes rs ON oi.apparel_id = rs.apparel_id
            UNION ALL
            SELECT
                'basketball shoes' AS product_type,
                COUNT(*) AS total_orders
            FROM
                com303fpfm.order_items oi
            INNER JOIN
                basketball_shoes bs ON oi.apparel_id = bs.apparel_id
            UNION ALL
            SELECT
                't-shirts' AS product_type,
                COUNT(*) AS total_orders
            FROM
                com303fpfm.order_items oi
            INNER JOIN
                tshirts t ON oi.apparel_id = t.apparel_id
            UNION ALL
            SELECT
                'polos' AS product_type,
                COUNT(*) AS total_orders
            FROM
                com303fpfm.order_items oi
            INNER JOIN
                polos p ON oi.apparel_id = p.apparel_id
            UNION ALL
            SELECT
                'sweatpants' AS product_type,
                COUNT(*) AS total_orders
            FROM
                com303fpfm.order_items oi
            INNER JOIN
                sweatpants sp ON oi.apparel_id = sp.apparel_id
            UNION ALL
            SELECT
                'casual pants' AS product_type,
                COUNT(*) AS total_orders
            FROM
                com303fpfm.order_items oi
            INNER JOIN
                casual_pants cp ON oi.apparel_id = cp.apparel_id
            ORDER BY
                total_orders DESC
            LIMIT 3;
        '''

        cursor.execute(query)

        info = cursor.fetchall()
        table = PrettyTable()
        table.field_names = ["Apparel Type", " Quantity"]
        for item in info:
            product, quantity = item
            table.add_row([product, quantity])
        # return table
        return table

    # output 10 top_selling products in each store
    def top_selling_products_by_store(self):
        query = '''
        SELECT  
            s.store_id, 
            a.apparel_id, 
            a.item_name, 
            SUM(oi.quantity) AS total_sold 
        FROM 
            stores s
        JOIN 
            has h ON s.store_id = h.store_id
        JOIN 
            order_items oi ON h.apparel_id = oi.apparel_id
        JOIN 
            apparel a ON h.apparel_id = a.apparel_id
        GROUP BY 
            s.store_id, a.apparel_id, a.item_name
        ORDER BY
            s.store_id, total_sold DESC'''

        cursor.execute(query)

        info = cursor.fetchall()

        store = 1
        products_for_store = []
        counter = 1
        for (storeid, item_id, name, totalsold) in info:
            if storeid == store and counter < 20:
                products_for_store.append([storeid, item_id, name, totalsold])
                counter += 1
            if counter == 2:
                store += 1
                counter = 1
        print(len(products_for_store))
        table = PrettyTable()
        table.field_names = ["Store ID", "Apparel ID", "Apparel Name", "Total Sold"]
        for item in products_for_store:
            storeid, item_id, name, totalsold = item
            table.add_row([storeid, item_id, name, totalsold])
        # return table
        return table

        # # create table
        # table = PrettyTable()
        # table.field_names = ["Store ID","Apparel ID", "Apparel Name", "Quantity Sold"]

        # hashmap = {}
        # for item in info:
        #     store, item_id, item_name, total_sold = item
        #     if store not in hashmap:
        #         hashmap[store] = 1
        #     else:
        #         hashmap[store] += 1
            
        #     # get top k products in each state
        #     if hashmap[store] <= 2:
        #         # add rows to the table
        #         table.add_row([store, item_id, item_name, total_sold])
        # return table


def main():
    query = Query()
    print(query.top_selling_products_by_store())

if __name__ == "__main__":
    main()


