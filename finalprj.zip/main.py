from queries import Query
from prettytable import PrettyTable
import mysql.connector

cnx = mysql.connector.connect(user='com303nle6', password='nl2520nl',
                              host='136.244.224.221',
                              database='com303nle6')


# display products for a store
def display_menu(store_id):
    try:
        cursor = cnx.cursor()
        query = """
            SELECT a.UPC, a.item_name, a.price, a.size, a.color
            FROM apparel a
            JOIN has h ON a.apparel_id = h.apparel_id
            WHERE h.store_id = %s
        """
        cursor.execute(query, (store_id,))
        products = cursor.fetchall()

        if not products:
            print("No products available in this store.")
        else:
            # Create table
            table = PrettyTable()
            table.field_names = ["Apparel No.","UPC","Name", "Price", "Size", "Color"]
            for idx, product in enumerate(products):
                upc, name, price, size, color = product
                table.add_row([idx+1, upc, name, price, size, color])

            # Set alignment for numeric columns
            table.align["Price"] = "r"

            # Print the table
            print("Menu of Products in Store " + str(store_id))
            print(table)

    except mysql.connector.Error as err:
        print(f"Error: {err}")

    finally:
        # Close cursor and connection
        cursor.close()
        cnx.close()

def sign_up():
    first_name = input("Enter your first name: ")
    last_name = input("Enter your last name: ")
    email = input("Enter your email: ")
    
    cursor = cnx.cursor()
    cursor.execute(
        '''
            select count(*) 
            from users
            where username = %s
        ''', (email,)
    )
    info = cursor.fetchall()
    while info[0][0] > 0:
        print("This email already exists.")
        email = input("Enter your email: ")
        cursor.execute(
        '''
            select count(*) 
            from users
            where username = %s
        ''', (email,)
        )
        info = cursor.fetchall()

    password = input("Enter your password: ")
    phone_number = input("Enter your phone number: ")
    address = input("Enter your address: ")
    city = input("Enter your city: ")
    state = input("Enter your state: ")
    membership = True

    cursor.execute(
        '''
            insert into customers 
            values (null,%s,%s,%s,%s,%s,%s,%s,%s)
        ''', (first_name, last_name, email, phone_number, address, city, state, membership)
    )

    cursor.execute(
        '''
            insert into users
            values (%s,%s,"C")
        ''', (email, password)
    )

    cursor.close()
    cnx.close()
    print("Account created successfully.")
    main()

def display_store():
    cnx.reconnect()
    cursor = cnx.cursor()
    cursor.execute(
        '''
            select store_id, state
            from stores
        '''
    )
    stores = cursor.fetchall()
    table = PrettyTable()
    table.field_names = ["Store", "State"]
    for store in stores:
        store_id, state = store
        table.add_row([store_id, state])
    # Print the table
    print("Menu of Products in Store " + str(store_id))
    print(table)

    choice = input("Enter the store number: ")
    while int(choice) < 1 or int(choice) > 29:
        choice = input("Enter a valid store number: ")
    
    cursor.close()
    cnx.close()

    return choice



def customer_menu():
    store_id = display_store()
    display_menu(store_id)
    print("Select an option:")
    print("1. Add product to cart")
    print("2. Exit")
    choice = input("Enter your choice: ")
    
    # add products to cart
    while int(choice) != 2:
        item = input("Enter UPC of the product: ")
        cart = {} #key-value pair is UPC and quantity
        if item not in cart:
            cart[item] = 1
        else:
            cart[item] += 1
        
        print("Select an option:")
        print("1. Add another product to cart")
        print("2. Check out")
        choice = input("Enter your choice: ")   

    print("show cart")
    # check out
    check_out = cnx.cursor()
    check_out.execute(
        '''
        select * from apparel
    '''
    )
    product_info = check_out.fetchall()
    print(product_info)
        # for UPC in cart:
    #     quantity = cart[UPC]
    #     print(UPC)
    #     # check_out.execute(
    #     #     '''
    #     #         select item_name, size, price, color
    #     #         from apparel
    #     #         where UPC = %s
    #     #     ''', (UPC,)
    #     # )
    #     check_out.execute(
    #         '''
    #         select * from apparel
    #     '''
    #     )
        # product_info = check_out.fetchall()
        # print(product_info)
    # table = PrettyTable()
    # table.field_names = ["No.", "Item Name", "Size", "Price", "Color", "Quantity"]
    # for idx, info in enumerate(product_info):
    #     name, size, price, color = info
    #     table.add_row([idx+1, name, size, price, color, quantity])
    # # Print the table
    # print("Products in your cart:" )
    # print(table)


    # choose store and show menu: 
    #   1. display products 
    #          add product to cart
    #   2. view order history
    # if there is purchase action -> check out
    #   take in info about email and credit card
    # exit

customer_menu()

def login():
    # check email in database
    email = input("Enter your email: ")
    password = input("Enter your password: ")

    cursor = cnx.cursor()
    cursor.execute(
        '''
            select user_role 
            from users
            where username = %s
            and user_password = %s
        ''', (email, password)
    )
    info = cursor.fetchall()
    if not info:
        print("Invalid username or password.")
        login()
    elif info[0][0] == "C":
        customer_menu()
    elif info[0][0] == "a":
        admin_menu()
    


def guest_login():
    store_id = display_store()
    display_menu(store_id)
    print("Select an option:")
    print("1. Add product to cart")
    print("2. Exit")
    choice = int(input("Enter your choice: "))
    
    # add products to cart
    while choice!= 2:
        if choice == 1:
            item = input("Enter UPC of the product: ")
            cart = {} #key-value pair is UPC and quantity
            if item not in cart:
                cart[item] = 1
            else:
                cart[item] += 1
            
            print("Select an option:")
            print("1. Add another product to cart")
            print("2. Check out")
            choice = input("Enter your choice: ")   
        else:
            print("Invalid option")

    # check out
    for UPC in cart:
        quantity = cart[UPC]
        cursor = cnx.cursor()
        cursor.execute(
            '''
                select item_name, size, price, color
                from apparel
                where UPC = %s
            ''', (UPC,)
        )
        product_info = cursor.fetchall()
        table = PrettyTable()
        table.field_names = ["No.", "Item Name", "Size", "Price", "Color", "Quantity"]
        for idx, info in enumerate(product_info):
            name, size, price, color = info
            table.add_row([idx+1, name, size, price, color, quantity])
        # Print the table
        print("Products in your cart:" )
        print(table)

    # choose store and show menu
    # add product to cart
    # if there is purchase action -> check out
    #   take in info about email and credit card
    # exit



def admin_menu():
    query = Query()
    while True: 
        print("\nPlease choose a query:")
        print("1. 20 top-selling products at each store")
        print("2. 20 top-selling products in each state")
        print("3. Top 5 stores in terms of product sold this year")
        print("4. In which stores does Item A outsell Item B?")
        print("5. Top 3 categories of product that customers buy")
        print("6. Total revenue of in-person orders for a specific range of time")
        print("7. Total revenue of online orders for a specific range of time")
        print("8. Total revenue in each store in descending order")
        print("0. Exit")
        
        choice = input("Enter your choice (0-8): ")
        
        if choice == "0":
            print("Exiting...")
            main()
            break
        elif choice == "1":
            query.top_selling_products_by_store()
        elif choice == "2":
            query.top_selling_products_by_state()
        elif choice == "3":
            query.top_stores_by_sales(5)
        elif choice == "4":
            item_a = input("Enter Item A: ")
            item_b = input("Enter Item B: ")
            query.t(item_a, item_b)
        elif choice == "5":
            query.top_selling_categories()
        # elif choice == "6":
        #     time_period = input("Enter time period : ")
        #     query.()
        # elif choice == "7":
        #     time_period = input("Enter time period : ")
        #     query.()
        # elif choice == "8":
        #     query.()
        else:
            print("Invalid choice. Please try again.")

def main():
    print("Welcome to Nike!")

    while True:
        print("\nUser Login:")
        print("1. Customer")
        print("2. Admin")
        print("3. Continue as guest")
        print("4. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            customer_login()
        elif choice == "2":
            admin_login()
        elif choice == "3":
            guest_login()
        elif choice == "4":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

# if __name__ == "__main__":
#     main()




# order history: order id, items, upc
